package org.usfirst.frc.team540.robot;

import edu.wpi.first.wpilibj.AnalogInput;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SD540;
import edu.wpi.first.wpilibj.interfaces.Gyro;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.Victor;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.networktables.NetworkTable;

public class Robot extends IterativeRobot {

	final String defaultAuto = "Default";
	final String customAuto = "My Auto";
	String autoSelected;
	SendableChooser<String> chooser = new SendableChooser<>();
	
	SD540 frontRight, frontLeft, backRight, backLeft;
	Joystick left, right;
	AnalogInput uS;
	
	double distance;
	
	double yLeft, yRight;
	//Making this a double allows you to be more precise
	
	/**
	 * Initialization
	 */
	
	@Override
	public void robotInit() {
		chooser.addDefault("Zachs Def Auto", defaultAuto);
		chooser.addObject("My Auto", customAuto);
		SmartDashboard.putData("Auto choices", chooser);
		
		frontRight = new SD540(0);
		frontLeft = new SD540(1);
		backRight = new SD540(2);
		backLeft = new SD540(3);
		left = new Joystick(0);
		right = new Joystick(1);
		
	}
	
	/**
	 * Autonomous code
	 */
	
	@Override
	public void autonomousInit() {
		autoSelected = chooser.getSelected();
		// autoSelected = SmartDashboard.getString("Auto Selector", 
		// default auto);
		System.out.println("Auto selected: " + autoSelected);
	}
	
	/**
	 * Periodic code in Autonomous
	 */
	
	public void autonomousPer() {
		distance = (uS.getVoltage()/0.009765625);
		switch(autoSelected) {
		case customAuto:
		System.out.println("Test code customAuto");
		//something
			break;
		case defaultAuto:
		default:
			System.out.println("Test code defaultAuto");
			//something
			break;
		}
	}
	
	/**
	 * Periodic code in operator control
	 */
	
	public void teleopPer() {
		yLeft = left.getY();
		yRight = -right.getY();
		
		//No deadzone!!! Yay!
		
		if (Math.abs(yLeft) < 0.2)
		{
			frontLeft.set(0);
			backLeft.set(0);
		}
		else
		{
			frontLeft.set(yLeft);
			backLeft.set(yLeft);
		}
		
		if (Math.abs(yRight) < 0.2)
		{
			frontRight.set(0);
			backRight.set(0);
		}
		else
		{
			frontRight.set(yRight);
			backRight.set(yRight);
		}
	}
	
	//Periodic testing code that spams your console with "REEEEEEEEEEEEEEEEEEEEEEEEEEE"
	public void testPer() {
		System.out.println("REEEEEEEEEEEEEEEEEEEEE");
	}
	
	
	
}
